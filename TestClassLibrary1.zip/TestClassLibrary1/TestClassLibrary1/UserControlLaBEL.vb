﻿Imports System.ComponentModel
Imports System.Data.SqlClient


Public Class UserControlLaBEL




    Dim m As Integer
    Dim n As Integer



    Public Shared str As String


        <Browsable(True),
Category("_MISC"), System.ComponentModel.Description("Enter Starting Index")>
        Public Property startingnum() As Integer
            Get
                Return m
            End Get
            Set(value As Integer)
                m = value
            End Set
        End Property


        <Browsable(True),
Category("_MISC"), System.ComponentModel.Description("Enter num for Consecutive numbers
")>
        Public Property consecutivenum() As Integer
            Get
                Return n
            End Get
            Set(value As Integer)
                n = value
            End Set
        End Property



    'This function returns a string starting from m in the int16array to next n consecutive numbers 
    Public Function result()


        str = ""
        MyBase.Text = ""
        Dim i As Integer
        ' arr = ar

        Dim newArray() As Short = DatabaseHandler.RetrieveValuesAsArray




        For i = m To m + n - 1
            If str = "" Then
                str = str + "" + newArray(i).ToString
            Else
                str = str + "," + newArray(i).ToString

            End If



        Next i


        Label1.Text = str




    End Function



End Class






