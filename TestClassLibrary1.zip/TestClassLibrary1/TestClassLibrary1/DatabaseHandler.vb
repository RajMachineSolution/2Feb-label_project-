﻿
Imports System.Data.SqlClient
Imports System.Windows
Imports System.Windows.Forms

Public Class DatabaseHandler




    Private Shared _instance As DatabaseHandler
    Private Shared connectionString As String = "Data Source=desktop-asus;Initial Catalog=sahil;Integrated Security=True"
    Public Shared array12() As Int16


    ' Shared method to get a shareable string from a column
    Public Shared Function RetrieveValuesAsArray() As Int16()
        ' Define the list to store values
        Dim int16List As New List(Of Int16)

        ' SQL query to retrieve values from the VARCHAR column
        Dim query As String = "SELECT D FROM D1000 where sno=1"

        ' Create SqlConnection and SqlCommand

        Try
            Using con As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, con)
                    ' Open the connection
                    con.Open()

                    ' Execute the query
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        ' Check if there are rows returned
                        If reader.HasRows Then
                            ' Iterate through the rows
                            While reader.Read()
                                ' Get the value from the VARCHAR column
                                Dim valuesAsString As String = reader.GetString(0)

                                ' Split the values by comma
                                Dim valuesArray As String() = valuesAsString.Split(",")


                                ' Convert each value to Int16 and add to the list
                                For Each value As String In valuesArray
                                    Dim intValue As Int16
                                    If Int16.TryParse(value, intValue) Then
                                        int16List.Add(intValue)
                                    Else
                                        ' Handle the case where conversion fails
                                        Console.WriteLine("Failed to convert value: " & value)
                                    End If
                                Next
                            End While
                        End If
                    End Using
                End Using
            End Using

            ' Convert the list to an array
            array12 = int16List.ToArray()

            Return array12



        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try
    End Function



End Class
